package serveletFiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class RegAct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
    public RegAct() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,IllegalStateException{
		String name=request.getParameter("name");//1
		String gender = request.getParameter("gender");//2
		String email=request.getParameter("email");//3
		String phno=request.getParameter("phno");//4
		String pwd =RandomPassword.generate();//5
		String pin = request.getParameter("pincode");//6
		String addr = request.getParameter("addr");//7
    	String img = request.getParameter("pic");//8
    	//System.out.println(img);
    	if(img == "") {
    		//Add path of default image
    		img = "defaultPic.png";
    	}
    	//System.out.println(img);
    	//System.out.println(name+"\n"+addr+"\n"+date+"\n"+gender+"\n"+phno+"\n"+pwd+"\n"+email+"\n"+img);
		PreparedStatement pstmt = null;
		FileInputStream fis=null;
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			String sql="INSERT INTO person (" + 
					"name," +"gender," +"email ," +  
					"phno ," +"password," +"pincode ,"+ 
					"address ," +"image)" + 
					"VALUES (" +"?, ?, ?, ?, ?, ?, ?, ?" + 
			");";
			File image = new File(img);
			pstmt = conn.prepareStatement(sql);
			fis=new FileInputStream(image);
			pstmt.setString(1, name);
			pstmt.setString(2, gender);
			pstmt.setString(3, email);
			pstmt.setString(4, phno);
			pstmt.setString(5, pwd);
			pstmt.setString(6, pin);
			pstmt.setString(7, addr);
			pstmt.setBinaryStream(8, (InputStream) fis, (int) (image.length()));
			int i=pstmt.executeUpdate();
			if(i>0) {
				//Success
				
				final String emailId ="mip.missing.people.org01@gmail.com";
				final String mailPassword = "Missing_people";
				final String subject =" Your MissingPeople.org Password Generated";
				final String msg= "<h2>Thank you for registrating </h2>"
						+ "<br><h3>Your password is : <i>"+pwd+"</i></h3><br>Please do not share your password with anyone."
						+ "The Management is not responsible if you share your account password to anyone.";
				
				
				SendMail.sendMail(email, emailId, mailPassword, subject, msg);
				
				sql = "INSERT INTO passwords(email,password) VALUES ('"+email+"', '"+pwd+"');";
				//int a = pstmt.executeUpdate(sql);
				//if(a>0) {
					//Success
				//}else {
					//Failed to add new password in DB
				//}
				response.sendRedirect("regSuccess.html");
			}
			else {
				//Failed
				response.sendRedirect("regErr.html");
			}
		} catch (Exception e) {
			//Failed due to exception
			response.sendRedirect("regErr.html");
			e.printStackTrace();
		}
	}
}