package serveletFiles;

import java.util.Random;

public class RandomPassword {
	public static String generate() {
		Random random = new Random();
		final String temp = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890!@#$%^&*_+?;";
		String res ="";
		int size = random.nextInt(15);
		while(size<7) {
			size = random.nextInt(15);
		}
		for (int i = 0; i < size; i++) {
			res+=temp.charAt(random.nextInt(temp.length()));
		}
		return res;
	}
}
