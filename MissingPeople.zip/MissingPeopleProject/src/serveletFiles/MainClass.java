package serveletFiles;

public class MainClass {

	public static void main(String[] args) throws Exception {
		String email = ""; //recepient mail
		@SuppressWarnings("unused")
		String pwd = RandomPassword.generate();
		final String emailId =""; //Type sender email here
		final String mailPassword = "";//Type sender password here
		final String subject =" ";//Type subject
		final String msg= "";//Type message here
		SendMail.sendMail(email, emailId, mailPassword, subject, msg);
	}
}
