package serveletFiles;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdatePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdatePassword() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String prevPass = request.getParameter("ppwd");
		String newPass = request.getParameter("npwd");
		HttpSession session = request.getSession();
		String email = session.getAttribute("key").toString();
		
		//Update password in person table
		//Insert new password in password table
		
		
		Statement stmt= null;
		Connection conn = null;
		ResultSet rs = null;
		
		String sql ="UPDATE person SET password = '"
		+newPass+"' ,verified = 'Verified' WHERE email = '"+email
		+"' AND password = '"+prevPass+"'";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			stmt = conn.createStatement();
			int i = stmt.executeUpdate(sql);
			if(i>0) {
				//Success
				//For forget password
				sql = "INSERT INTO passwords(email,password) VALUES ('"+email+"', '"+newPass+"');";
				int a = stmt.executeUpdate(sql);
				if(a>0) {
					//Success
				}else {
					//Failed to add new password in DB
				}
				//For different login pages
				sql = "SELECT * FROM person WHERE email ='"+email+"' AND password = '"+newPass+"'";
				rs = stmt.executeQuery(sql);
				if(rs.next()) {
					//Login based on job
					String job=(String)rs.getString("job"); 
					if(job.equals("Admin")) {
						//Admin home page
						response.sendRedirect("adminHome.jsp");
					}
					else if(job.equals("OrphOwner")) {
						//Orphan Owner
						response.sendRedirect("orphOwnHome.jsp");
					}
					else if(job.equals("Police") || job.equals("User")) {
						//Police or user login
						response.sendRedirect("userCopHome.jsp");
					}	
					rs.close();
				}
				else {
					//Something went wrong while updating password
					//Message = Password was not updated please try again
					response.sendRedirect("updatePassword.jsp?msg=Password was not updated please try again");
				}
			}
			else {
				//Something went wrong
				//Message = Wrong password or email entered
				response.sendRedirect("updatePassword.jsp?msg=Wrong password or email entered");
			}
			stmt.close();
			conn.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}