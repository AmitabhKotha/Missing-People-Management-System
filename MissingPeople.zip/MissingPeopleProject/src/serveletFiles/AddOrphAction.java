package serveletFiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("unused")
public class AddOrphAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AddOrphAction() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String email =session.getAttribute("key").toString();
		String name=request.getParameter("name");//1
		String gname = request.getParameter("gname");//2
		String gender = request.getParameter("gender");//3
		String age = request.getParameter("age");//4
		String addr = request.getParameter("addr");//5
		String pin = request.getParameter("pincode");//6
		String orphName = null;//7
    	String img = request.getParameter("pic");//8
    	String status = request.getParameter("status");//9
    	
    	System.out.println(status);
    	
    	String postedBy = null;//10
    	String sql=null;
    	
    	//System.out.println(img);
    	Statement stmt=null;
		PreparedStatement pstmt = null;
		FileInputStream fis=null;
		ResultSet rs = null;
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			sql="SELECT * FROM PERSON WHERE email = '"+email+"'";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				postedBy = rs.getString("id");
			}
			sql = "INSERT INTO child ( name, guardianName, gender, age, address, pincode, orphName, image, status, postedBy)" + 
							"VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = conn.prepareStatement(sql);
			File image = new File(img);
			fis=new FileInputStream(image);
			pstmt.setString(1, name);
			pstmt.setString(2, gname);
			pstmt.setString(3, gender);
			pstmt.setString(4, age);
			pstmt.setString(5, addr);
			pstmt.setString(6, pin);
			pstmt.setString(7, orphName);
			pstmt.setBinaryStream(8, (InputStream) fis, (int) (image.length()));
			pstmt.setString(9, status);
			pstmt.setString(10, postedBy);
			int i=pstmt.executeUpdate();
			if(i>0) {
				//Success
				//Preview post need to be created
				conn.close();
				stmt.close();
				pstmt.close();
				response.sendRedirect("previewPost.jsp?name="+name+"&gname="+gname+"&postedBy="+postedBy+"");
			}
			else {
				//Failed		
				response.sendRedirect("error.jsp");
			}
		} catch (Exception e) {
			//Failed due to exception
			response.sendRedirect("error.jsp");
			e.printStackTrace();
		}
	}
}