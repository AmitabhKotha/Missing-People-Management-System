package serveletFiles;

public class Madlibs {
	//Adding a child found by some user
	public static String foundChild(String cname,String gname,String age,String gender,String address,String postedBy) {
		String result = cname+" is a "+age+" years old "+gender+" child , whose guardian is , "+gname+" and resides in "+address+". The child was found by "+postedBy
				+". If anyone wants to know about the child please contact "+postedBy+".";
		return result;
	}
	
	//Report about a missing child
	public static String missingChild(String cname,String gname,String age,String gender,String address) {
		String result = "I , "+gname+" has lost my child,"+cname+" , who is "+age+" years old and "+gender
				+" who residing in "+address+". If child is found please contact me. Thank you.";
		return result;
	}
	
	//Adding a new Child to orphanage
	public static String orphChild(String cname,String age,String gender) {
		String result = "We are happy to announce that , "+cname+" a "+age+" year old "+gender+" child has recently joined our orphanage."+
						"If anyone wants to know about the child please contact us.";
		return result;
	}
	public static String adoptChild(String cname,String adoptName) {
		String result =null;
		result = "We are happy to announce that "+cname+" was adopted by our user "+adoptName+".We hope that "+cname+" will live happily with "+adoptName+".";
		return result;
	}
	public static String foundChild(String cname,String gender,String adoptName) {
		String result =null;
		String gen=null;
		if(gender.equalsIgnoreCase("male")) {
			gen = "his";
		}
		else {
			gen = "her";
		}
		result = "We are happy to announce that "+cname+" was found by "+gen+" guardian, "+adoptName+".We hope that "+cname+" will live happily with "+adoptName+"."+adoptName
		+" is thankful to all the users of this website,including you.";
		return result;
	}
}
