package serveletFiles;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateField extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UpdateField() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String field = request.getParameter("field");
		String value = request.getParameter("value");
		String sql = "UPDATE person SET "+field+" = '"+value+"'";
		Connection conn = null;
		Statement stmt=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			stmt = conn.createStatement();
			int i = stmt.executeUpdate(sql);
			if(i>0) {
				response.sendRedirect("updateProfile.jsp");
			}
			else {
				response.sendRedirect("error.jsp");
			}
		} catch (Exception e) {			
			e.printStackTrace();
		}
	}
}
