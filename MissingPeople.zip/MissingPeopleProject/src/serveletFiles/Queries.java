package serveletFiles;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Queries {
	static Connection conn;
	static Statement stmt;
	private static void init() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			stmt = conn.createStatement();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static ResultSet jobProfiles(String job) {
		init();
		String sql = "SELECT NAME,EMAIL FROM PERSON WHERE JOB LIKE '%"+job+"%'ORDER BY DATE";
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			rs=null;
			e.printStackTrace();
		} 
		return rs;
	}
	
	public static ResultSet executecurrentQuery(String sql) {
		init();
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			rs=null;
			e.printStackTrace();
		} 
		return rs;
	}
	
	public static int executecurrentUpdate(String sql) {
		init();
		int x=0;
		try {
			x = stmt.executeUpdate(sql);
		} catch (SQLException e) {
			x=-1;
			e.printStackTrace();
		} 
		return x;
	}
}
