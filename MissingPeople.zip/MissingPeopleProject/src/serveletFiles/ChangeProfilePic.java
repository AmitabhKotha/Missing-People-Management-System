package serveletFiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("unused")
public class ChangeProfilePic extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ChangeProfilePic() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String img = request.getParameter("pic");//9
		
		HttpSession session = request.getSession();
		String email = session.getAttribute("key").toString();
		
		System.out.println(img);
		
    	if(img == "" || img.equals("Remove Profile Picture")) {
    		img = "D:\\Java FSD Internships\\Final Project\\MissingPeopleProject\\WebContent\\defaultPic.png";
    	}
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			String sql="UPDATE person SET image = ? WHERE email='"+email+"'";
	    	PreparedStatement pstmt = null;
			FileInputStream fis=null;
			File image = new File(img);
			pstmt = conn.prepareStatement(sql);
			fis=new FileInputStream(image);
			pstmt.setBinaryStream(1, (InputStream) fis, (int) (image.length()));
			int i = pstmt.executeUpdate();
			if(i>0) {
				response.sendRedirect("changeProfilePic.jsp?msg=Profile Pic Updated Successfully.");
			}
			else {
				response.sendRedirect("changeProfilePic.jsp?msg=Profile Pic Updated Failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
