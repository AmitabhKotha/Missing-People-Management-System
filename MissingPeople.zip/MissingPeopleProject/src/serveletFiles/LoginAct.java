package serveletFiles;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginAct extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LoginAct() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		HttpSession session = request.getSession();
		session.setAttribute("key", email);
		
		Statement stmt= null;
		ResultSet rs=null;
		Connection conn = null;
		String sql = "SELECT * FROM person WHERE email ='"+email+"' AND password='"+pwd+"'";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				int loginCount =rs.getInt("login_count");
				String  verified = rs.getString("verified");
				if(!verified.equalsIgnoreCase("Verified")) {
					//Change password page
					sql = "UPDATE person SET login_count = login_count+1 WHERE email ='"+email+"'";
					int x = stmt.executeUpdate(sql);
					if(x>0) {
						response.sendRedirect("updatePassword.jsp");
					}else {
						response.sendRedirect("loginErr.html");
					}
				}
				else if(verified.equalsIgnoreCase("blocked")) {
					response.sendRedirect("blockedProfile.html");
				}
				else {
					String job=rs.getString("job"); 
					sql = "UPDATE person SET login_count=login_count+1 WHERE email ='"+email+"'";
					stmt.executeUpdate(sql);
					
					if(job.equals("Admin")) {
						//Admin home page
						response.sendRedirect("adminHome.jsp");
					}
					else if(job.equals("OrphOwner")) {
						//Orphan Owner
						response.sendRedirect("orphOwnHome.jsp");
					}
					else if(job.equals("Police") || job.equals("User")) {
						//Police or user login
						response.sendRedirect("userCopHome.jsp");
					}	
				}
			}
			else {
				//Error occured while trying to login
				response.sendRedirect("loginErr.html");
			}
			stmt.close();
			conn.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
