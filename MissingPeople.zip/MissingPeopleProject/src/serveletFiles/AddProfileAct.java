package serveletFiles;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddProfileAct extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AddProfileAct() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String name=request.getParameter("name");//1
		String gender = request.getParameter("gender");//2
		String email=request.getParameter("email");//3
		String job =request.getParameter("job");//4
		String phno=request.getParameter("phno");//5
		String pwd =RandomPassword.generate();//6
		String pin = request.getParameter("pincode");//7
		String addr = request.getParameter("addr");//8
    	String img = "defaultPic.png";//9
    	
    	
		PreparedStatement pstmt = null;
		FileInputStream fis=null;
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			String sql="INSERT INTO person (" + 
					"name," +"gender," +"email ," +"job,"+  
					"phno ," +"password," +"pincode ,"+ 
					"address ," +"image)" + 
					"VALUES (" +"?, ?, ?, ?, ?, ?, ?, ?, ?" + 
			");";
			File image = new File(img);
			pstmt = conn.prepareStatement(sql);
			fis=new FileInputStream(image);
			pstmt.setString(1, name);
			pstmt.setString(2, gender);
			pstmt.setString(3, email);
			pstmt.setString(4, job);
			pstmt.setString(5, phno);
			pstmt.setString(6, pwd);
			pstmt.setString(7, pin);
			pstmt.setString(8, addr);
			pstmt.setBinaryStream(9, (InputStream) fis, (int) (image.length()));
			int i=pstmt.executeUpdate();
			if(i>0) {
				//Success
				
				final String emailId ="mip.missing.people.org01@gmail.com";
				final String mailPassword = "Missing_people";
				final String subject =" Your MissingPeople.org Password Generated";
				final String msg= "<h2>Thank you for registrating </h2>"
						+ "<br><h3>Your password is : <i>"+pwd+"</i></h3><br>Please do not share your password with anyone."
						+ "The Management is not responsible if you share your account password to anyone.";
				
				
				SendMail.sendMail(email, emailId, mailPassword, subject, msg);
				
				sql = "INSERT INTO passwords(email,password) VALUES ('"+email+"', '"+pwd+"');";
				
				int a = pstmt.executeUpdate(sql);
				if(a>0) {
					//Success
				}else {
					//Failed to add new password in DB
				}
				response.sendRedirect("ProfileAdded.html");
			}
			else {
				//Failed
				response.sendRedirect("profileAddError.html");
			}
		} catch (Exception e) {
			response.sendRedirect("profileAddError.html");
			e.printStackTrace();
		}
	}
}
