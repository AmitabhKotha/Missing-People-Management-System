package serveletFiles;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForgetPassAct extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public ForgetPassAct() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		//HttpSession session = request.getSession();
		
		//System.out.println(pwd);
		
		Statement stmt= null;
		Connection conn = null;
		ResultSet rs = null;
		
		String sql ="SELECT * FROM passwords WHERE email = '"+email+"' AND password = '"+pwd+"'";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				//Success
				
				//For forget password
				String newPass = RandomPassword.generate();
				
				//Message in email
				String msg = "<h1>Your request for a new password is accepted.</h1>"
							  + "<br><h2>Your new password is : "+newPass+"</h2>"
							  + "<br><h3>Please update your password as soon as possible."
							  + "<br>Thank You.</h3>";
				
				sql = "INSERT INTO passwords(email,password) VALUES ('"+email+"', '"+newPass+"');";
				
				int a = stmt.executeUpdate(sql);
				
				if(a>0) {//Inserting into passwords table failed 
				
					//Send mail to email address
					SendMail.sendMail(email, "amitabh.kotha5900@gmail.com", "Amitabh@5900", "New Password Generated", msg);
					
					//Update password in person table
					sql = "UPDATE person SET password = '"+newPass+"'";
					
					int b = stmt.executeUpdate(sql);
					if(b>0){//Updating password in person table
					  //Success
						response.sendRedirect("passwordUpdated.html");//Prompt to some page that is not yet created
					}
					else{
					 	//Update failed
						response.sendRedirect("passUpdateFailed.jsp?msg=Password was not updated in Previous passwords.");
					}
				}else {
					//Failed to add new password in DB
					response.sendRedirect("passUpdateFailed.jsp?msg=Password was not updated in current profile.");
				}
			}
			else {
				//Something went wrong
				//Message = Wrong password or email entered
				//wrong password entered , prompt to other page  
				response.sendRedirect("passUpdateFailed.jsp?msg=User email or password did not match.Please try again");
			}
			stmt.close();
			conn.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}