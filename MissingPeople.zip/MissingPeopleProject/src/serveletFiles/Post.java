package serveletFiles;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Post {
	static Connection conn;
	static Statement stmt;
	 private static void init() {
		//Edit sql part
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/missingpeople", "root", "");
				stmt = conn.createStatement();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
	}
	 
	 
	public static ResultSet allPosts() {
		init();
		String sql = "SELECT C.ID AS CID, C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.AGE AS CAGE, C.FOUNDDATE AS CFD, C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH, C.STATUS AS CSTATUS,C.GENDER AS CGENDER, C.POSTEDBY AS CPB, C.RESPONDEDBY AS CRP, P.ID AS PID, P.NAME AS PNAME, P.EMAIL AS PEMAIL FROM CHILD C, PERSON P WHERE C.POSTEDBY = P.ID AND C.STATUS NOT IN ('ADOPTED','BLOCKED','FOUND','adopted','found','guardian','GUARDIAN') ORDER BY C.FOUNDDATE";
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			rs=null;
		} 
		return rs;
	}
	
	public static ResultSet reportedPosts() {
		init();
		String sql = "SELECT C.ID AS CID, C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.AGE AS CAGE, C.FOUNDDATE AS CFD, C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH,  C.STATUS AS CSTATUS,C.GENDER AS CGENDER, C.POSTEDBY AS CPB,C.RESPONDEDBY AS CRP, P.ID AS PID, P.NAME AS PNAME, P.EMAIL AS PEMAIL FROM CHILD C, PERSON P WHERE C.POSTEDBY = P.ID AND C.STATUS LIKE '%REPORTED%' ORDER BY C.FOUNDDATE";
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
			rs=null;
		} 
		return rs;
	}
	
	public static ResultSet childPost(String id) {
		init();
		
		String sql = "SELECT C.ID AS CID, C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.AGE AS CAGE, C.FOUNDDATE AS CFD, "+
					 "C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH, C.GENDER AS CGENDER, C.STATUS AS CSTATUS, "+
					 "C.POSTEDBY AS CPB,C.RESPONDEDBY AS CRP, P.ID AS PID, P.NAME AS PNAME, P.EMAIL AS PEMAIL" + 
					 "FROM CHILD C, PERSON P" + 
					 "WHERE C.POSTEDBY = P.ID AND C.id = "+Integer.parseInt(id)+ 
					 "ORDER BY C.FOUNDDATE";
	
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			rs=null;
			e.printStackTrace();
		} 
		return rs;
	}
	
	
	public static ResultSet orphPost(String orphName) {
		init();
		
		String sql = "SELECT C.ID AS CID, C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.AGE AS CAGE, C.FOUNDDATE AS CFD, "+
					 "C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH,C.GENDER AS CGENDER, C.STATUS AS CSTATUS, "+
					 "C.POSTEDBY AS CPB, C.RESPONDEDBY AS CRP,P.ID AS PID, P.NAME AS PNAME, P.EMAIL AS PEMAIL, P.IMAGE AS PIMG" + 
					 "FROM CHILD C, PERSON P" + 
					 "WHERE C.POSTEDBY = P.ID AND C.ORPHNAME = "+orphName+ 
					 "ORDER BY C.FOUNDDATE";
		//String sql = "SELECT * FROM child C,person P WHERE C.orphName = "+orphName+" C.postedBy = P.id ORDER BY C.foundDate";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			rs=null;
			e.printStackTrace();
		} 
		return rs;
	}
	
	public static ResultSet childDetails(String id) {
		init();
		
		String sql = "SELECT C.ID AS CID ,C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.AGE AS CAGE, C.FOUNDDATE AS CFD, C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH,C.GENDER AS CGENDER,C.RESPONDEDBY AS CRP,P.NAME AS PNAME,P.EMAIL AS PEMAIL FROM CHILD C, PERSON P WHERE C.POSTEDBY = P.ID AND C.ID = '"+Integer.parseInt(id)+"'";
		
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return rs;
	}
	public static ResultSet adoptedFound() {
		init();
		
		String sql = "SELECT C.ID AS CID ,C.NAME AS CNAME, C.GUARDIANNAME AS CGNAME, C.STATUS AS CSTATUS, C.AGE AS CAGE, C.FOUNDDATE AS CFD, C.ADDRESS AS CADDR, C.PINCODE AS CPIN, C.ORPHNAME AS CORPH,C.GENDER AS CGENDER,C.RESPONDEDBY AS CRP,P.NAME AS PNAME,P.EMAIL AS PEMAIL FROM CHILD C, PERSON P WHERE C.POSTEDBY = P.ID AND C.STATUS IN ('ADOPTED','FOUND','adopted','found','guardian','GUARDIAN');";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return rs;
	}
}
